/**
 * Rei Launcher — Renderer Process
 * Handles all UI logic for the Electron renderer.
 */

// ─── State ────────────────────────────────────────────
const state = {
  accounts: [],
  activeAccount: null,
  versions: [],
  activeVersion: null,
  screenshots: [],
  settings: { ram: 2048, javaPath: '' },
  isRunning: false
}

// ─── Init ─────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  initWindowControls()
  initNavigation()
  initButtonActions()
  await loadAppState()
  setupIpcListeners()
})

// ─── Window Controls ──────────────────────────────────
function initWindowControls() {
  const { launcher } = window
  document.getElementById('btn-minimize')?.addEventListener('click', () => launcher.window.minimize())
  document.getElementById('btn-maximize')?.addEventListener('click', () => launcher.window.maximize())
  document.getElementById('btn-close')?.addEventListener('click', () => launcher.window.close())
}

// ─── Navigation ───────────────────────────────────────
function initNavigation() {
  document.querySelectorAll('.nav-btn[data-page]').forEach(btn => {
    btn.addEventListener('click', () => navigateTo(btn.dataset.page))
  })

  // Card "go to page" links
  document.querySelectorAll('[data-page]').forEach(el => {
    if (!el.classList.contains('nav-btn')) {
      el.addEventListener('click', () => navigateTo(el.dataset.page))
    }
  })
}

function navigateTo(pageId) {
  document.querySelectorAll('.nav-btn[data-page]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.page === pageId)
  })
  document.querySelectorAll('.page').forEach(page => {
    page.classList.toggle('active', page.id === `page-${pageId}`)
  })
}

// ─── Button Actions ───────────────────────────────────
function initButtonActions() {
  // Modrinth
  document.getElementById('btn-modrinth')?.addEventListener('click', () => window.launcher.modrinth.open())

  // Home page
  document.getElementById('btn-launch-home')?.addEventListener('click', launchGame)
  document.getElementById('btn-open-accounts-home')?.addEventListener('click', () => navigateTo('accounts'))

  // Accounts page
  document.getElementById('btn-add-offline')?.addEventListener('click', addOfflineAccount)
  document.getElementById('btn-add-microsoft')?.addEventListener('click', addMicrosoftAccount)

  // Versions page
  document.getElementById('btn-download-version')?.addEventListener('click', downloadVersion)

  // Skins page
  document.getElementById('btn-open-namemc')?.addEventListener('click', openNameMC)
  document.getElementById('btn-copy-skin-link')?.addEventListener('click', copySkinLink)
  document.getElementById('skin-username')?.addEventListener('input', refreshSkinPreview)

  // Settings page
  document.getElementById('btn-detect-java')?.addEventListener('click', detectJava)
  document.getElementById('ram-slider')?.addEventListener('input', onRamChange)
}

// ─── IPC Listeners ────────────────────────────────────
function setupIpcListeners() {
  window.launcher.on.downloadProgress(progress => {
    const area = document.getElementById('download-progress')
    const fill = document.getElementById('download-bar-fill')
    const label = document.getElementById('download-bar-label')
    if (!area) return
    area.classList.remove('hidden')
    if (fill) fill.style.width = `${progress.percent || 0}%`
    if (label) label.textContent = `${progress.type || ''}  ${progress.downloaded || 0} / ${progress.total || 0}`
  })

  window.launcher.on.gameLog(log => {
    // Optionally show log in console (for future console panel)
    console.log('[GAME]', log.type, log.message)
  })
}

// ─── Load App State ───────────────────────────────────
async function loadAppState() {
  await loadSettings()
  await loadAccounts()
  await loadVersions()
  await loadScreenshots()
  refreshHomePanel()
  refreshSkinPreview()
}

async function loadSettings() {
  try {
    const settings = await window.launcher.settings.get()
    if (settings) {
      state.settings = settings
      const slider = document.getElementById('ram-slider')
      const display = document.getElementById('ram-value')
      if (slider) slider.value = settings.ram || 2048
      if (display) display.textContent = settings.ram || 2048
      updateJavaDisplay(settings.javaPath)
    }
  } catch (e) { console.error('loadSettings:', e) }
}

async function loadAccounts() {
  try {
    state.accounts = await window.launcher.accounts.get() || []
    state.activeAccount = await window.launcher.accounts.getActive()
    if (!state.activeAccount && state.accounts.length > 0) {
      state.activeAccount = await window.launcher.accounts.setActive(state.accounts[0].id)
    }
    renderAccountList()
  } catch (e) { console.error('loadAccounts:', e) }
}

async function loadVersions() {
  try {
    state.versions = await window.launcher.versions.get() || []
    renderVersionList()
  } catch (e) { console.error('loadVersions:', e) }
}

async function loadScreenshots() {
  try {
    state.screenshots = await window.launcher.screenshots.get() || []
    renderScreenshots()
  } catch (e) { console.error('loadScreenshots:', e) }
}

// ─── Home Panel ───────────────────────────────────────
function refreshHomePanel() {
  const account = state.activeAccount

  // Header chip
  const chipName = document.getElementById('chip-name')
  const chipType = document.getElementById('chip-type')
  const chipAvatar = document.getElementById('chip-avatar')
  if (chipName) chipName.textContent = account?.username || 'No Account'
  if (chipType) chipType.textContent = account ? (account.type === 'offline' ? 'Offline' : 'Microsoft') : '—'
  if (chipAvatar) chipAvatar.textContent = account ? account.username[0].toUpperCase() : '?'

  // Header title
  const headerUser = document.getElementById('header-username')
  if (headerUser) headerUser.textContent = account ? `, ${account.username}` : ''

  // Stats
  setText('stat-accounts', state.accounts.length)
  setText('stat-versions', state.versions.length)
  setText('stat-screenshots', state.screenshots.length)

  // Version badge
  const versionBadge = document.getElementById('info-badge-version')
  const versionDetail = document.getElementById('info-version-detail')
  const heroVersion = document.getElementById('hero-version-display')
  if (state.activeVersion) {
    if (versionBadge) versionBadge.textContent = state.activeVersion
    if (versionDetail) versionDetail.textContent = `Minecraft ${state.activeVersion} is selected and ready to launch.`
    if (heroVersion) heroVersion.textContent = `Minecraft ${state.activeVersion}`
  } else if (state.versions.length > 0) {
    const latest = state.versions[state.versions.length - 1]
    state.activeVersion = latest
    if (versionBadge) versionBadge.textContent = latest
    if (heroVersion) heroVersion.textContent = `Minecraft ${latest}`
    if (versionDetail) versionDetail.textContent = `Minecraft ${latest} ready to launch.`
  }

  // Screenshots badge
  setText('info-badge-shots', state.screenshots.length)

  // Mini screenshots
  const miniGrid = document.getElementById('mini-screenshots')
  if (miniGrid) {
    miniGrid.innerHTML = ''
    const recent = state.screenshots.slice(0, 4)
    if (recent.length === 0) {
      miniGrid.innerHTML = '<span class="empty-hint">No screenshots yet</span>'
    } else {
      recent.forEach(p => {
        const img = document.createElement('img')
        img.src = p
        img.alt = 'screenshot'
        miniGrid.appendChild(img)
      })
    }
  }
}

// ─── Account List ─────────────────────────────────────
function renderAccountList() {
  const container = document.getElementById('accounts-list')
  if (!container) return
  container.innerHTML = ''

  if (!state.accounts.length) {
    container.innerHTML = '<div class="empty-state">No accounts added yet.</div>'
    return
  }

  state.accounts.forEach(account => {
    const isActive = state.activeAccount?.id === account.id
    const row = document.createElement('div')
    row.className = `account-row ${isActive ? 'is-active' : ''}`
    row.innerHTML = `
      <div class="account-row-left">
        <span class="account-row-name">${account.username}</span>
        <span class="account-row-type">${account.type === 'offline' ? 'Offline' : 'Microsoft'}</span>
      </div>
      <div class="account-row-actions">
        <button class="small-btn ${isActive ? 'active-btn' : ''}" data-action="activate" data-id="${account.id}">
          ${isActive ? 'Active' : 'Use'}
        </button>
        <button class="small-btn danger" data-action="remove" data-id="${account.id}">Remove</button>
      </div>
    `
    container.appendChild(row)
  })

  container.querySelectorAll('[data-action="activate"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const account = await window.launcher.accounts.setActive(btn.dataset.id)
      if (account) {
        state.activeAccount = account
        toast(`Active: ${account.username}`, 'success')
        renderAccountList()
        refreshHomePanel()
        refreshSkinPreview()
      }
    })
  })

  container.querySelectorAll('[data-action="remove"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      await window.launcher.accounts.remove(btn.dataset.id)
      await loadAccounts()
      refreshHomePanel()
    })
  })
}

// ─── Version List ─────────────────────────────────────
function renderVersionList() {
  const container = document.getElementById('version-items')
  if (!container) return
  container.innerHTML = ''

  if (!state.versions.length) {
    container.innerHTML = '<div class="empty-state">No versions installed. Download one →</div>'
    return
  }

  state.versions.slice().reverse().forEach(version => {
    const isActive = state.activeVersion === version
    const row = document.createElement('div')
    row.className = `version-row ${isActive ? 'is-active' : ''}`
    row.innerHTML = `
      <span class="version-name">${version}</span>
      <button class="small-btn ${isActive ? 'active-btn' : ''}" data-action="select" data-version="${version}">
        ${isActive ? 'Selected' : 'Select'}
      </button>
    `
    container.appendChild(row)
  })

  container.querySelectorAll('[data-action="select"]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.activeVersion = btn.dataset.version
      toast(`Version ${state.activeVersion} selected`, 'success')
      renderVersionList()
      refreshHomePanel()
    })
  })
}

// ─── Screenshots ──────────────────────────────────────
function renderScreenshots() {
  const grid = document.getElementById('screenshots-grid')
  if (!grid) return
  grid.innerHTML = ''

  if (!state.screenshots.length) {
    grid.innerHTML = '<div class="screenshots-empty">No screenshots found in .minecraft/screenshots</div>'
    return
  }

  state.screenshots.forEach(filePath => {
    const item = document.createElement('div')
    item.className = 'screenshot-item'
    const img = document.createElement('img')
    img.src = filePath
    img.alt = 'screenshot'
    item.appendChild(img)
    item.addEventListener('click', () => window.launcher.screenshots.open(filePath))
    grid.appendChild(item)
  })
}

// ─── Skins ────────────────────────────────────────────
function refreshSkinPreview() {
  const input = document.getElementById('skin-username')
  const username = input?.value?.trim() || state.activeAccount?.username || ''
  const img = document.getElementById('skin-preview-current')
  const details = document.getElementById('skin-preview-details')
  if (!username) return
  if (img) img.src = `https://mc-heads.net/body/${encodeURIComponent(username)}`
  if (details) details.textContent = `Showing skin for: ${username}`
}

function openNameMC() {
  const username = document.getElementById('skin-username')?.value?.trim()
    || state.activeAccount?.username || ''
  window.launcher.skins.openNameMC(username)
}

function copySkinLink() {
  const username = document.getElementById('skin-username')?.value?.trim()
    || state.activeAccount?.username || ''
  if (!username) { toast('No username set', 'error'); return }
  navigator.clipboard.writeText(`https://mc-heads.net/skin/${username}`)
  toast('Skin URL copied!', 'success')
}

// ─── Launch ───────────────────────────────────────────
async function launchGame() {
  if (state.isRunning) { toast('Game is already running!', 'info'); return }
  if (!state.activeAccount) { toast('Please add an account first', 'error'); navigateTo('accounts'); return }
  if (!state.activeVersion) { toast('Please select a version first', 'error'); navigateTo('versions'); return }

  state.isRunning = true
  const btn = document.getElementById('btn-launch-home')
  if (btn) { btn.textContent = 'Launching...'; btn.disabled = true }

  toast(`Launching Minecraft ${state.activeVersion}…`, 'info')

  const config = {
    version: state.activeVersion,
    javaPath: state.settings.javaPath || 'java'
  }

  try {
    const result = await window.launcher.minecraft.launch(config)
    if (result.success) {
      toast('Game launched successfully!', 'success')
    } else {
      toast(`Launch failed: ${result.error}`, 'error')
    }
  } catch (e) {
    toast(`Error: ${e.message}`, 'error')
  } finally {
    state.isRunning = false
    if (btn) { btn.innerHTML = '<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd"/></svg> Launch Game'; btn.disabled = false }
  }
}

// ─── Add Offline Account ──────────────────────────────
async function addOfflineAccount() {
  const input = document.getElementById('offline-username')
  const username = input?.value?.trim()
  if (!username) { toast('Please enter a username', 'error'); return }

  const result = await window.launcher.accounts.addOffline(username)
  if (result.success) {
    toast(`Account "${username}" added`, 'success')
    if (input) input.value = ''
    await loadAccounts()
    refreshHomePanel()
  } else {
    toast(result.error || 'Failed to add account', 'error')
  }
}

// ─── Add Microsoft Account ────────────────────────────
async function addMicrosoftAccount() {
  toast('Opening Microsoft login…', 'info')
  const result = await window.launcher.accounts.addMicrosoft()
  if (result.success) {
    toast(`Microsoft account added: ${result.account.username}`, 'success')
    await loadAccounts()
    refreshHomePanel()
  } else {
    toast(result.error || 'Microsoft login failed', 'error')
  }
}

// ─── Download Version ─────────────────────────────────
async function downloadVersion() {
  const input = document.getElementById('version-download-input')
  const version = input?.value?.trim()
  if (!version) { toast('Enter a version number', 'error'); return }

  const area = document.getElementById('download-progress')
  if (area) {
    area.classList.remove('hidden')
    area.innerHTML = `
      <div class="progress-bar-wrap"><div class="progress-bar-fill" id="download-bar-fill" style="width:0%"></div></div>
      <span class="progress-label" id="download-bar-label">Starting download…</span>
    `
  }

  toast(`Downloading Minecraft ${version}…`, 'info')
  const result = await window.launcher.minecraft.download(version)
  if (result.success) {
    toast(`Minecraft ${version} downloaded!`, 'success')
    if (input) input.value = ''
    if (area) area.classList.add('hidden')
    await loadVersions()
    state.activeVersion = version
    refreshHomePanel()
  } else {
    toast(result.error || 'Download failed', 'error')
    if (area) area.classList.add('hidden')
  }
}

// ─── Java Detection ───────────────────────────────────
async function detectJava() {
  const result = await window.launcher.java.detect()
  const label = document.getElementById('java-path-label')
  const badgeJava = document.getElementById('info-badge-java')
  const detailJava = document.getElementById('info-java-detail')

  if (result.installed) {
    const version = result.version || 'unknown'
    updateJavaDisplay(version, true)
    state.settings.javaPath = 'java'
    await window.launcher.settings.set(state.settings)
    toast(`Java ${version} detected`, 'success')
    if (badgeJava) badgeJava.textContent = `Java ${result.major || '?'}`
    if (detailJava) detailJava.textContent = `Java ${version} found. Compatible with Minecraft.`
  } else {
    toast('Java not found. Please install Java 17+', 'error')
    if (label) { label.textContent = 'Java not found'; label.className = 'java-status-box' }
  }
}

function updateJavaDisplay(path, isOk = false) {
  const label = document.getElementById('java-path-label')
  if (!label) return
  label.textContent = path || 'No Java detected'
  label.className = `java-status-box${isOk ? ' ok' : ''}`
}

// ─── RAM ──────────────────────────────────────────────
function onRamChange(e) {
  const value = Number(e.target.value)
  state.settings.ram = value
  const display = document.getElementById('ram-value')
  if (display) display.textContent = value
  window.launcher.settings.set({ ...state.settings, ram: value })
}

// ─── Helpers ──────────────────────────────────────────
function setText(id, text) {
  const el = document.getElementById(id)
  if (el) el.textContent = text
}

function toast(message, type = 'info') {
  const container = document.getElementById('toast-container')
  if (!container) return
  const el = document.createElement('div')
  el.className = `toast ${type}`
  el.textContent = message
  container.appendChild(el)
  setTimeout(() => el.remove(), 3100)
}
