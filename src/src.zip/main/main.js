const { app, BrowserWindow, ipcMain, shell } = require('electron')
const fs = require('fs')
const path = require('path')
const { authenticateMicrosoft } = require('./auth/microsoft')
const { createOfflineAccount } = require('./auth/offline')
const { launchMinecraft } = require('./launcher/launch')
const { detectJava } = require('./launcher/java')
const { downloadVersion } = require('./launcher/download')
const { getInstances, createInstance, deleteInstance } = require('./instances/manager')
const store = require('./store/store')

function getAccounts() {
  return store.get('accounts') || []
}

function saveAccounts(accounts) {
  store.set('accounts', accounts)
}

function addOrUpdateAccount(account) {
  const accounts = getAccounts()
  const existingIndex = accounts.findIndex(a => a.id === account.id)
  if (existingIndex >= 0) {
    accounts[existingIndex] = account
  } else {
    accounts.unshift(account)
  }
  saveAccounts(accounts)
  store.set('account', account)
  return account
}

function removeAccountById(id) {
  const accounts = getAccounts().filter(account => account.id !== id)
  saveAccounts(accounts)
  if (store.get('account')?.id === id) {
    if (accounts.length > 0) {
      store.set('account', accounts[0])
    } else {
      store.delete('account')
    }
  }
  return accounts
}

function getMinecraftFolder() {
  return path.join(app.getPath('appData'), '.minecraft')
}

function getVersionsFolder() {
  return path.join(getMinecraftFolder(), 'versions')
}

function getScreenshotsFolder() {
  return path.join(getMinecraftFolder(), 'screenshots')
}

let mainWindow

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#00000000',
    transparent: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: false
    }
  })
  mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'))
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools()
  }
  mainWindow.on('closed', () => { mainWindow = null })
}
app.whenReady().then(createWindow)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

ipcMain.on('window:minimize', () => mainWindow.minimize())
ipcMain.on('window:maximize', () => {
  mainWindow.isMaximized() ? mainWindow.restore() : mainWindow.maximize()
})
ipcMain.on('window:close', () => mainWindow.close())
ipcMain.handle('auth:microsoft', async () => {
  return await authenticateMicrosoft(mainWindow)
})
ipcMain.handle('auth:offline', async (event, username) => {
  return await createOfflineAccount(username)
})
ipcMain.handle('java:detect', async () => {
  return await detectJava()
})
ipcMain.handle('minecraft:download', async (event, version) => {
  return await downloadVersion(version, (progress) => {
    mainWindow.webContents.send('download:progress', progress)
  })
})
ipcMain.handle('minecraft:launch', async (event, config) => {
  return await launchMinecraft(config, (log) => {
    mainWindow.webContents.send('game:log', log)
  })
})
ipcMain.handle('instances:get', async () => getInstances())
ipcMain.handle('instances:create', async (event, data) => createInstance(data))
ipcMain.handle('instances:delete', async (event, id) => deleteInstance(id))
ipcMain.handle('settings:get', () => store.get('settings'))
ipcMain.handle('settings:set', (event, data) => store.set('settings', data))
ipcMain.handle('account:get', () => store.get('account'))
ipcMain.handle('account:set', (event, data) => store.set('account', data))
ipcMain.handle('account:clear', () => store.delete('account'))
ipcMain.handle('accounts:get', () => getAccounts())
ipcMain.handle('account:getActive', () => store.get('account'))
ipcMain.handle('account:setActive', (event, id) => {
  const account = getAccounts().find(a => a.id === id)
  if (account) {
    store.set('account', account)
    return account
  }
  return null
})
ipcMain.handle('account:remove', (event, id) => {
  const accounts = removeAccountById(id)
  return { success: true, accounts }
})
ipcMain.handle('account:addOffline', async (event, username) => {
  const result = await createOfflineAccount(username)
  if (!result.success) return result
  const account = addOrUpdateAccount(result.account)
  return { success: true, account }
})
ipcMain.handle('account:addMicrosoft', async () => {
  const result = await authenticateMicrosoft()
  if (!result.success) return result
  const account = addOrUpdateAccount(result.account)
  return { success: true, account }
})
ipcMain.handle('versions:get', async () => {
  const versionsDir = getVersionsFolder()
  if (!fs.existsSync(versionsDir)) return []
  return fs.readdirSync(versionsDir)
    .filter(name => fs.statSync(path.join(versionsDir, name)).isDirectory())
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
})
ipcMain.handle('screenshots:get', async () => {
  const shotsDir = getScreenshotsFolder()
  if (!fs.existsSync(shotsDir)) return []
  return fs.readdirSync(shotsDir)
    .filter(file => /\.(png|jpg|jpeg)$/i.test(file))
    .map(file => path.join(shotsDir, file))
})
ipcMain.handle('screenshots:open', async (event, filePath) => {
  return shell.openPath(filePath)
})
ipcMain.handle('modrinth:open', async () => {
  const modal = new BrowserWindow({
    width: 1200,
    height: 820,
    title: 'Modrinth',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  })
  modal.loadURL('https://modrinth.com/')
  return { success: true }
})
ipcMain.handle('skins:openNameMC', async (event, username) => {
  const url = username ? `https://namemc.com/profile/${encodeURIComponent(username)}` : 'https://namemc.com/'
  const modal = new BrowserWindow({
    width: 1120,
    height: 840,
    title: 'NameMC',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  })
  modal.loadURL(url)
  return { success: true }
})