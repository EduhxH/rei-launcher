const Store = require('electron-store')

const store = new Store({
  name: 'config',
  defaults: {
    settings: {
      ram: 2048,
      width: 1280,
      height: 720,
      closeOnLaunch: false,
      javaPath: ''
    },
    instances: [],
    accounts: [],
    account: null
  }
})

module.exports = store
