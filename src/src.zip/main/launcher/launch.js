const { Client, Authenticator } = require('minecraft-launcher-core')
const path = require('path')
const { app } = require('electron')
const store = require('../store/store')
const { v4: uuidv4 } = require('uuid')

const MINECRAFT_DIR = path.join(app.getPath('appData'), '.rei-launcher')

// Reuse single Client to prevent EMFILE (too many open files)
let launcherInstance = null
function getLauncher() {
  if (!launcherInstance) launcherInstance = new Client()
  return launcherInstance
}

async function launchMinecraft(config, onLog) {
  const account = store.get('account')
  const settings = store.get('settings') || { ram: 2048 }

  if (!account) {
    return { success: false, error: 'No account configured. Add an account first.' }
  }

  let auth
  try {
    if (account.type === 'offline') {
      // Authenticator.getAuth(user) with no password = offline mode
      auth = await Authenticator.getAuth(account.username)
    } else {
      auth = {
        access_token: account.accessToken,
        client_token: account.clientToken || uuidv4(),
        uuid: account.uuid,
        name: account.username,
        user_properties: '{}'
      }
    }
  } catch (_) {
    auth = { access_token: account.uuid || uuidv4(), client_token: uuidv4(), uuid: account.uuid || uuidv4(), name: account.username, user_properties: '{}' }
  }

  const ram = settings.ram || 2048

  const launchOptions = {
    version: { number: config.version, type: 'release' },
    root: config.instancePath || MINECRAFT_DIR,
    authorization: auth,
    javaPath: config.javaPath || settings.javaPath || 'java',
    memory: { max: `${ram}M`, min: `${Math.max(512, Math.floor(ram / 2))}M` },
    window: { width: settings.width || 1280, height: settings.height || 720 },
    overrides: { detached: false }
  }

  const launcher = getLauncher()
  launcher.removeAllListeners('debug')
  launcher.removeAllListeners('data')
  launcher.removeAllListeners('close')

  return new Promise((resolve) => {
    launcher.on('debug', msg => onLog({ type: 'debug', message: String(msg) }))
    launcher.on('data', data => onLog({ type: 'info', message: String(data).trim() }))
    launcher.on('close', code => {
      launcherInstance = null
      onLog({ type: code === 0 ? 'success' : 'error', message: `Game exited with code ${code}` })
    })

    // launch() downloads missing files AND starts the game automatically
    launcher.launch(launchOptions)
      .then(proc => resolve(proc
        ? { success: true }
        : { success: false, error: 'Launch returned null — check Java (java -version)' }))
      .catch(err => { launcherInstance = null; resolve({ success: false, error: err.message }) })
  })
}

module.exports = { launchMinecraft }