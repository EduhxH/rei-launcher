const { exec } = require('child_process')
const util = require('util')
const execAsync = util.promisify(exec)

async function detectJava() {
  try {
    const { stdout, stderr } = await execAsync('java -version 2>&1')
    const output = stdout || stderr
    const versionMatch = output.match(/version "(\d+)(?:\.(\d+))?"/)

    if (!versionMatch) {
      return { installed: true, version: 'unknown', major: 0 }
    }

    const first = parseInt(versionMatch[1])
    const second = parseInt(versionMatch[2] || '0')
    const major = first === 1 ? second : first

    return {
      installed: true,
      version: versionMatch[0].replace('version "', ''),
      major,
      compatible: {
        legacy: major >= 8,
        modern: major >= 17,
        latest: major >= 21
      }
    }

  } catch (error) {
    return {
      installed: false,
      error: 'Java não encontrado. Instala o Java 17+ ou 21.'
    }
  }
}

module.exports = { detectJava }
