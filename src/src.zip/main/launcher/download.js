const { Client, Authenticator } = require('minecraft-launcher-core')
const path = require('path')
const { app } = require('electron')

const MINECRAFT_DIR = path.join(app.getPath('appData'), '.rei-launcher')

/**
 * "Download" a version by doing a headless launch with a dummy offline auth.
 * minecraft-launcher-core downloads all assets/libraries before starting the game.
 * We immediately kill the process after download completes (on 'data' first line = game started).
 * This is the correct approach — there's no separate install() method in MCLC v3.
 */
async function downloadVersion(version, onProgress) {
  const launcher = new Client()

  let auth
  try {
    auth = await Authenticator.getAuth('download_user')
  } catch (_) {
    auth = { access_token: 'download', client_token: 'download', uuid: 'download', name: 'download_user', user_properties: '{}' }
  }

  const options = {
    version: { number: version, type: 'release' },
    root: MINECRAFT_DIR,
    authorization: auth,
    javaPath: 'java',
    memory: { max: '512M', min: '256M' },
    overrides: { detached: false }
  }

  return new Promise((resolve) => {
    let resolved = false

    launcher.on('debug', msg => {
      const message = String(msg)
      onProgress({ type: 'debug', message, percent: -1 })

      // Detect download progress from debug messages
      const dlMatch = message.match(/Downloading (\d+)\/(\d+)/)
      if (dlMatch) {
        const done = parseInt(dlMatch[1])
        const total = parseInt(dlMatch[2])
        onProgress({ type: 'downloading', task: done, total, percent: Math.round((done / total) * 100) })
      }

      // Game started — kill it, we only wanted the files
      if (message.includes('Setting user') || message.includes('logged in')) {
        if (!resolved) {
          resolved = true
          try { if (launcher._client) launcher._client.kill() } catch (_) {}
          resolve({ success: true })
        }
      }
    })

    launcher.on('data', _ => {
      // Any game output = successfully launched = files are downloaded
      if (!resolved) {
        resolved = true
        try { if (launcher._client) launcher._client.kill() } catch (_) {}
        resolve({ success: true })
      }
    })

    launcher.on('close', code => {
      if (!resolved) {
        resolved = true
        resolve(code === 0 || code === null
          ? { success: true }
          : { success: false, error: `Process closed with code ${code}` })
      }
    })

    launcher.launch(options).catch(err => {
      if (!resolved) {
        resolved = true
        resolve({ success: false, error: err.message })
      }
    })
  })
}

module.exports = { downloadVersion }